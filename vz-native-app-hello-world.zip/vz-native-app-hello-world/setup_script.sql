CREATE APPLICATION ROLE IF NOT EXISTS app_user;
CREATE SCHEMA IF NOT EXISTS core;
GRANT USAGE ON SCHEMA core TO APPLICATION ROLE app_user;

CREATE OR REPLACE STREAMLIT core.hello_world_streamlit
  FROM '/streamlit'
  MAIN_FILE = 'hello_streamlit.py';

GRANT USAGE ON STREAMLIT core.hello_world_streamlit TO APPLICATION ROLE app_user;
