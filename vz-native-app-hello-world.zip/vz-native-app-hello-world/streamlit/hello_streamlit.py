import streamlit as st

st.set_page_config(page_title="Hello World", page_icon="❄️")
st.title("❄️ Hello World!")
st.write("Welcome to my first Snowflake Native App.")
st.write("This Streamlit app is running **inside** Snowflake — no external infrastructure needed.")
name = st.text_input("What's your name?", placeholder="Enter your name...")
if name:
    st.success(f"Hey {name}, welcome to the Snowflake Marketplace! 🎉")
st.divider()
st.caption("Built with Streamlit on Snowflake · Powered by the Native App Framework")
