-- ============================================================================
-- Hello World Native App — Setup Script
-- ============================================================================
-- HOW TO USE THIS FILE:
--   1. Upload this ENTIRE FOLDER into your default Snowflake Workspace, aka
--      "My Workspace" (Snowsight -> Projects -> Workspaces -> My Workspace ->
--      + -> Upload Folder).
--   2. Open this file (00_setup.sql) inside the Workspace.
--   3. Run each statement one at a time (highlight it, then Cmd/Ctrl+Enter),
--      in order, top to bottom.
--
-- NOTE: This script assumes you uploaded the folder into "My Workspace"
-- (FQN: USER$.PUBLIC.DEFAULT$), which is the default personal workspace
-- every user has. If you instead uploaded it into a different workspace,
-- replace USER$.PUBLIC.DEFAULT$ in STEP 4 below with that workspace's FQN
-- (run SHOW WORKSPACES; to find it).
-- ============================================================================


-- ----------------------------------------------------------------------------
-- STEP 1: Set role and create the application package
-- ----------------------------------------------------------------------------
USE ROLE ACCOUNTADMIN;

CREATE APPLICATION PACKAGE IF NOT EXISTS hello_world_pkg;


-- ----------------------------------------------------------------------------
-- STEP 2: Create a schema inside the package to hold a stage
-- ----------------------------------------------------------------------------
CREATE SCHEMA IF NOT EXISTS hello_world_pkg.code;


-- ----------------------------------------------------------------------------
-- STEP 3: Create the stage that will hold the app's files
-- ----------------------------------------------------------------------------
CREATE STAGE IF NOT EXISTS hello_world_pkg.code.app_stage;


-- ----------------------------------------------------------------------------
-- STEP 4: Copy the app files from your Workspace onto the app stage
-- ----------------------------------------------------------------------------
-- If you uploaded the "vz-native-app-hello-world" folder directly into the
-- root of "My Workspace", the paths below are correct as-is.

COPY FILES
  INTO @hello_world_pkg.code.app_stage
  FROM 'snow://workspace/USER$.PUBLIC.DEFAULT$/versions/live/vz-native-app-hello-world/'
  FILES = ('manifest.yml', 'setup_script.sql', 'README.md');

COPY FILES
  INTO @hello_world_pkg.code.app_stage/streamlit/
  FROM 'snow://workspace/USER$.PUBLIC.DEFAULT$/versions/live/vz-native-app-hello-world/streamlit/'
  FILES = ('hello_streamlit.py');

-- Verify all 4 files made it onto the stage:
LIST @hello_world_pkg.code.app_stage;


-- ----------------------------------------------------------------------------
-- STEP 5: Create (install) the application from the package
-- ----------------------------------------------------------------------------
-- NOTE: CREATE APPLICATION does not support OR REPLACE. Drop any existing
-- app with this name first (no-op the first time you run this).
DROP APPLICATION IF EXISTS hello_world_app;

CREATE APPLICATION hello_world_app
  FROM APPLICATION PACKAGE hello_world_pkg
  USING '@hello_world_pkg.code.app_stage';


-- ----------------------------------------------------------------------------
-- STEP 6: View your app
-- ----------------------------------------------------------------------------
-- In Snowsight, go to Apps -> HELLO_WORLD_APP.
-- The Streamlit app loads with the "Hello World" greeting.
--
-- To iterate on the code: edit the files in this Workspace, re-run STEP 4 to
-- re-copy them to the stage, then run:
--   ALTER APPLICATION hello_world_app UPGRADE USING '@hello_world_pkg.code.app_stage';


-- ----------------------------------------------------------------------------
-- STEP 7 (optional): Version and release for the Marketplace
-- ----------------------------------------------------------------------------
DROP APPLICATION IF EXISTS hello_world_app;

ALTER APPLICATION PACKAGE hello_world_pkg
  ADD VERSION v1
  USING '@hello_world_pkg.code.app_stage';

ALTER APPLICATION PACKAGE hello_world_pkg
  SET DEFAULT RELEASE DIRECTIVE
  VERSION = v1
  PATCH = 0;

-- Private listing: Data Products -> Provider Studio -> + Create Listing ->
--   Only Specified Consumers -> select HELLO_WORLD_PKG as the Data Product.
--
-- Public Marketplace listing (requires Snowflake security scan, up to 24h):
-- ALTER APPLICATION PACKAGE hello_world_pkg SET DISTRIBUTION = EXTERNAL;
