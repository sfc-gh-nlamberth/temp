# Hello World App

A simple Streamlit app running natively on Snowflake.

## What It Does
- Greets you by name
- Demonstrates Streamlit running inside a Snowflake Native App

## Getting Started
Click **Get** to install the app. No configuration required.
